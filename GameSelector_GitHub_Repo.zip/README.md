# GameSelector (Paper 1.21.x)

A lightweight Paper plugin that gives players a locked **gold GameSelector compass** in slot 0.
Right‑click opens a custom chest GUI that matches your image layout (vanilla black background; icons via external resource pack).

## Features
- Locked compass on join (slot 0), `&6GameSelector`, glint.
- Right‑click opens a 27‑slot GUI titled `&6GameSelector`.
- Items at slots 10, 12, 14:
  - DIAMOND_SWORD (CMD 10001) → `&6Duels`
  - FILLED_MAP   (CMD 10002) → `&6World`
  - RED_BANNER   (CMD 10003) → `&6Factions`
- Each button runs a configurable command from `config.yml` (empty by default).

## Build (GitHub Actions)
Push this repo to GitHub. Actions will auto‑build and give you the JAR in **Artifacts**.

## Build (local)
```bash
mvn clean package
```
Find JAR in `target/`.

## Install
1. Drop `target/GameSelector-1.0.0.jar` into `plugins/`.
2. Start server once to generate config, then edit `plugins/GameSelector/config.yml`.
3. Restart or `/reload confirm`.

## Command
- `/gameselector` – opens the GUI.

## Permission
- `gameselector.use` – defaults to **true**.

## External Resource Pack
Make sure your resource pack provides CustomModelData:
- DIAMOND_SWORD → `10001`
- FILLED_MAP → `10002`
- RED_BANNER → `10003`
