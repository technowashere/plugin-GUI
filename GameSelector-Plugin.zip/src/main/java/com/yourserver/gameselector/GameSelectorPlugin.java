
package com.yourserver.gameselector;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;

public class GameSelectorPlugin extends JavaPlugin implements Listener {

    private NamespacedKey compassKey;
    private NamespacedKey menuKey;
    private Inventory cachedMenu;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        getServer().getPluginManager().registerEvents(this, this);
        if (getCommand("gameselector") != null) {
            getCommand("gameselector").setExecutor((sender, cmd, label, args) -> {
                if (sender instanceof Player p) {
                    openMenu(p);
                    return true;
                }
                sender.sendMessage("Players only.");
                return true;
            });
        }
        compassKey = new NamespacedKey(this, "gs_compass");
        menuKey = new NamespacedKey(this, "gs_item");
        buildMenu();
    }

    private void buildMenu() {
        String rawTitle = getConfig().getString("menu.title", "&6Game Selector");
        String title = ChatColor.translateAlternateColorCodes('&', rawTitle);
        int size = Math.max(9, Math.min(54, getConfig().getInt("menu.size", 27)));
        cachedMenu = Bukkit.createInventory(null, size, title);

        // Fill background
        String fillerName = getConfig().getString("menu.filler", "BLACK_STAINED_GLASS_PANE");
        Material fillerMat = Material.matchMaterial(fillerName);
        if (fillerMat == null) fillerMat = Material.BLACK_STAINED_GLASS_PANE;
        ItemStack filler = new ItemStack(fillerMat);
        ItemMeta fMeta = filler.getItemMeta();
        fMeta.setDisplayName(" ");
        fMeta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_ENCHANTS);
        filler.setItemMeta(fMeta);
        for (int i = 0; i < size; i++) cachedMenu.setItem(i, filler);

        // Place defined items
        ConfigurationSection items = getConfig().getConfigurationSection("menu.items");
        if (items != null) {
            for (String key : items.getKeys(false)) {
                ConfigurationSection sec = items.getConfigurationSection(key);
                if (sec == null) continue;
                int slot = sec.getInt("slot", -1);
                Material mat = Material.matchMaterial(sec.getString("material", "STONE"));
                String name = ChatColor.translateAlternateColorCodes('&', sec.getString("name", "&6Item"));
                int cmd = sec.getInt("customModelData", 0);
                if (slot < 0 || slot >= size || mat == null) continue;

                ItemStack it = new ItemStack(mat);
                ItemMeta meta = it.getItemMeta();
                meta.setDisplayName(name);
                if (cmd > 0) meta.setCustomModelData(cmd);
                meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_ENCHANTS);
                // Tag with logical key
                meta.getPersistentDataContainer().set(menuKey, PersistentDataType.STRING, key);
                it.setItemMeta(meta);
                cachedMenu.setItem(slot, it);
            }
        }
    }

    private ItemStack makeCompass() {
        ItemStack compass = new ItemStack(Material.COMPASS);
        ItemMeta meta = compass.getItemMeta();
        String name = ChatColor.translateAlternateColorCodes('&', getConfig().getString("compass.name", "&6Game Selector"));
        meta.setDisplayName(name);
        try { meta.setEnchantmentGlintOverride(true); } catch (Throwable ignored) {}
        meta.getPersistentDataContainer().set(compassKey, PersistentDataType.BYTE, (byte)1);
        compass.setItemMeta(meta);
        return compass;
    }

    private void giveCompass(Player p) {
        if (!getConfig().getBoolean("compass.enabled", true)) return;
        int slot = Math.max(0, Math.min(8, getConfig().getInt("compass.slot", 0)));
        ItemStack item = makeCompass();
        p.getInventory().setItem(slot, item);
        p.updateInventory();
    }

    private boolean isOurCompass(ItemStack stack) {
        if (stack == null || stack.getType() != Material.COMPASS || !stack.hasItemMeta()) return false;
        return stack.getItemMeta().getPersistentDataContainer().has(compassKey, PersistentDataType.BYTE);
    }

    private boolean isOurMenuItem(ItemStack stack) {
        if (stack == null || !stack.hasItemMeta()) return false;
        return stack.getItemMeta().getPersistentDataContainer().has(menuKey, PersistentDataType.STRING);
    }

    private void openMenu(Player p) {
        if (cachedMenu == null) buildMenu();
        p.openInventory(cachedMenu);
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        giveCompass(e.getPlayer());
    }

    @EventHandler
    public void onUse(PlayerInteractEvent e) {
        if (e.getItem() != null && isOurCompass(e.getItem())) {
            switch (e.getAction()) {
                case RIGHT_CLICK_AIR:
                case RIGHT_CLICK_BLOCK:
                    e.setCancelled(true);
                    openMenu(e.getPlayer());
                    break;
                default:
                    break;
            }
        }
    }

    @EventHandler
    public void onDrop(PlayerDropItemEvent e) {
        if (getConfig().getBoolean("compass.locked", true) &&
                isOurCompass(e.getItemDrop().getItemStack())) {
            e.setCancelled(true);
        }
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player p)) return;
        ItemStack current = e.getCurrentItem();

        // Lock moving the compass
        if (getConfig().getBoolean("compass.locked", true) &&
                (isOurCompass(current) || isOurCompass(e.getCursor()))) {
            e.setCancelled(true);
        }

        // Handle clicks inside our menu
        if (e.getView().getTopInventory() != null &&
                e.getView().getTopInventory().getType() == InventoryType.CHEST &&
                e.getView().getTitle().equals(ChatColor.translateAlternateColorCodes('&', getConfig().getString("menu.title", "&6Game Selector")))) {
            e.setCancelled(true); // prevent taking items
            if (isOurMenuItem(current)) {
                String key = current.getItemMeta().getPersistentDataContainer().get(menuKey, PersistentDataType.STRING);
                String runAs = getConfig().getString("menu.items."+key+".run_as", "console").toLowerCase();
                String cmd = getConfig().getString("menu.items."+key+".command", "").trim();
                p.closeInventory();
                if (!cmd.isEmpty()) {
                    if (runAs.equals("console")) {
                        Bukkit.dispatchCommand(Bukkit.getConsoleSender(), cmd.startsWith("/") ? cmd.substring(1) : cmd);
                    } else {
                        p.performCommand(cmd.startsWith("/") ? cmd.substring(1) : cmd);
                    }
                } else {
                    p.sendMessage(ChatColor.GRAY + "(placeholder) configure command for: " + key);
                }
            }
        }
    }
}
