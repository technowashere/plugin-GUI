# GameSelector (Paper 1.21.x)

Standalone plugin that gives players a locked **gold compass** in slot 0.
Right‑click opens a 27‑slot GUI titled `&6Game Selector` with three clickable items:

- Slot 11 → **RED_BANNER** (CMD 10003) → runs `/warp red` as **console**
- Slot 13 → **FILLED_MAP** (CMD 10002) → runs `/warp map` as **console**
- Slot 15 → **DIAMOND_SWORD** (CMD 10001) → runs `/warp pvp` as **console**

All other slots are filled with **BLACK_STAINED_GLASS_PANE** to match the default dark GUI look.

## Build locally
```bash
mvn clean package
```
Jar is in `target/`.

## GitHub Actions
Push to a repo with this folder at root. Actions builds and exposes the jar as an artifact.

## Configure
Edit `plugins/GameSelector/config.yml` after first run to change commands, names, and slots.

## Resource Pack
Host the provided `GameSelector-ResourcePack.zip` and set its URL in `server.properties`:
```
resource-pack=<DIRECT_URL_TO_ZIP>
```
Ensure it contains CustomModelData for:
- DIAMOND_SWORD → 10001
- FILLED_MAP    → 10002
- RED_BANNER    → 10003
